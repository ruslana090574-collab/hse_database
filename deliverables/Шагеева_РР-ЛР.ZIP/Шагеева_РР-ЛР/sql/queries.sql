-- 01_Клиенты_и_все_полисы
SELECT "PassportNo","FullName","BirthDate","Gender","PolicyID","IssuedOn","CountryName","PolicyCoverage","CurrencyLabel" FROM "PolicySummary" ORDER BY "PolicyID";

-- 02_Все_клиенты_включая_без_полисов
SELECT c."PassportNo",c."FullName",c."BirthDate",g."GenderName"||' ('||g."GenderSymbol"||')' AS "Gender",p."PolicyID",p."IssuedOn",s."CountryName",p."PolicyCoverage",v."AlphaCode" FROM "Client" c JOIN "Gender" g ON g."GenderCode"=c."GenderCode" LEFT JOIN "Policy" p ON p."PassportNo"=c."PassportNo" LEFT JOIN "Country" s ON s."CountryCode"=p."CountryCode" LEFT JOIN "Currency" v ON v."CurrencyCode"=p."PolicyCurrency" ORDER BY c."PassportNo",p."PolicyID";

-- 03_Количество_полисов_текущий_год
SELECT COUNT(*) AS "PoliciesCount" FROM "Policy" WHERE EXTRACT(YEAR FROM "IssuedOn")=EXTRACT(YEAR FROM CURRENT_DATE);

-- 04_Клиенты_с_полисами_текущий_год
SELECT c."PassportNo",c."FullName",c."BirthDate",COUNT(p."PolicyID") AS "PoliciesCount" FROM "Client" c JOIN "Policy" p ON p."PassportNo"=c."PassportNo" WHERE EXTRACT(YEAR FROM p."IssuedOn")=EXTRACT(YEAR FROM CURRENT_DATE) GROUP BY c."PassportNo",c."FullName",c."BirthDate" ORDER BY COUNT(p."PolicyID") DESC,c."PassportNo";

-- 05_Все_клиенты_полисы_текущий_год
SELECT c."PassportNo",c."FullName",c."BirthDate",COUNT(p."PolicyID") AS "PoliciesCount" FROM "Client" c LEFT JOIN "Policy" p ON p."PassportNo"=c."PassportNo" AND EXTRACT(YEAR FROM p."IssuedOn")=EXTRACT(YEAR FROM CURRENT_DATE) GROUP BY c."PassportNo",c."FullName",c."BirthDate" ORDER BY COUNT(p."PolicyID") DESC,c."PassportNo";

-- 06_Клиенты_максимальное_покрытие
SELECT DISTINCT "PassportNo","FullName","BirthDate","PolicyCoverage","CurrencyLabel" FROM "PolicySummary" WHERE "PolicyCoverage"=(SELECT MAX("PolicyCoverage") FROM "PolicySummary") ORDER BY "PassportNo";

-- 07_Клиенты_без_полисов_текущий_год
SELECT c."PassportNo",c."FullName",c."BirthDate" FROM "Client" c WHERE NOT EXISTS (SELECT 1 FROM "Policy" p WHERE p."PassportNo"=c."PassportNo" AND EXTRACT(YEAR FROM p."IssuedOn")=EXTRACT(YEAR FROM CURRENT_DATE)) ORDER BY c."PassportNo";

-- 08_Полисы_прошлый_год_для_отчёта
SELECT * FROM "PolicySummary" WHERE EXTRACT(YEAR FROM "IssuedOn")=EXTRACT(YEAR FROM CURRENT_DATE)-1 ORDER BY "PassportNo","PolicyID";

-- 09_Расчёт_стоимости_полисов
SELECT * FROM "PolicySummary" ORDER BY "PolicyID";

-- 10_Агенты_количество_за_период
SELECT a."AgentID",a."AgentName",COUNT(r."PolicyID") AS "PolicyCount" FROM "Agent" a LEFT JOIN "PolicySummary" r ON r."AgentID"=a."AgentID" AND r."IssuedOn">=:DateStart AND r."IssuedOn"<=:DateEnd GROUP BY a."AgentID",a."AgentName" ORDER BY a."AgentID";

-- 11_Агенты_выручка_за_период
SELECT a."AgentID",a."AgentName",COALESCE(SUM(r."PremiumRUB"),0) AS "RevenueRUB",COALESCE(SUM(ROUND(r."PremiumRUB"*r."CommissionPct"/100,2)),0) AS "CommissionRUB" FROM "Agent" a LEFT JOIN "PolicySummary" r ON r."AgentID"=a."AgentID" AND r."IssuedOn">=:DateStart AND r."IssuedOn"<=:DateEnd GROUP BY a."AgentID",a."AgentName" ORDER BY a."AgentID";

-- 12_Агенты_лидеры_за_период
SELECT a."AgentID",a."AgentName",COUNT(r."PolicyID") AS "PolicyCount" FROM "Agent" a LEFT JOIN "PolicySummary" r ON r."AgentID"=a."AgentID" AND r."IssuedOn">=:DateStart AND r."IssuedOn"<=:DateEnd GROUP BY a."AgentID",a."AgentName" HAVING COUNT(r."PolicyID")>0 AND COUNT(r."PolicyID") >= ALL (SELECT COUNT(r."PolicyID") FROM "Agent" a LEFT JOIN "PolicySummary" r ON r."AgentID"=a."AgentID" AND r."IssuedOn">=:DateStart AND r."IssuedOn"<=:DateEnd GROUP BY a."AgentID",a."AgentName") ORDER BY a."AgentID";

-- 13_Средняя_стоимость_за_период
SELECT COUNT(*) AS "PolicyCount",CAST(AVG("PremiumRUB") AS DECIMAL(14,2)) AS "AvgPremiumRUB" FROM "PolicySummary" WHERE "IssuedOn">=:DateStart AND "IssuedOn"<=:DateEnd;

-- 14_Агенты_средняя_стоимость
SELECT a."AgentID",a."AgentName",COUNT(r."PolicyID") AS "PolicyCount",CAST(AVG(r."PremiumRUB") AS DECIMAL(14,2)) AS "AvgPremiumRUB" FROM "Agent" a LEFT JOIN "PolicySummary" r ON r."AgentID"=a."AgentID" AND r."IssuedOn">=:DateStart AND r."IssuedOn"<=:DateEnd GROUP BY a."AgentID",a."AgentName" ORDER BY a."AgentID";

-- 15_Услуги_полисов_исторические
SELECT j."PolicyID",u."ServiceCode",u."ServiceName",k."CategoryName",j."TariffDate",j."AgreedPrice" FROM "PolicyService" j JOIN "Service" u ON u."ServiceCode"=j."ServiceCode" JOIN "ServiceCategory" k ON k."CategoryCode"=u."CategoryCode" ORDER BY j."PolicyID",u."ServiceCode";

-- 16_Услуги_актуальные_для_списка
SELECT * FROM "ServiceChoices" ORDER BY "ServiceCode";

-- 17_Агенты_архив
SELECT * FROM "Agent" WHERE "IsActive"=0;

-- 18_Покрытие_максимум_в_рублях
SELECT DISTINCT "PassportNo","FullName","CoverageRUB" FROM "PolicySummary" WHERE "CoverageRUB"=(SELECT MAX("CoverageRUB") FROM "PolicySummary") ORDER BY "PassportNo";

-- 19_Полисы_для_слияния_Writer
SELECT r."PolicyID",LPAD(CAST(EXTRACT(DAY FROM r."IssuedOn") AS VARCHAR(2)),2,'0')||'.'||LPAD(CAST(EXTRACT(MONTH FROM r."IssuedOn") AS VARCHAR(2)),2,'0')||'.'||CAST(EXTRACT(YEAR FROM r."IssuedOn") AS VARCHAR(4)) AS "IssuedOn",LPAD(CAST(EXTRACT(DAY FROM r."StartsOn") AS VARCHAR(2)),2,'0')||'.'||LPAD(CAST(EXTRACT(MONTH FROM r."StartsOn") AS VARCHAR(2)),2,'0')||'.'||CAST(EXTRACT(YEAR FROM r."StartsOn") AS VARCHAR(4)) AS "StartsOn",LPAD(CAST(EXTRACT(DAY FROM r."EndsOn") AS VARCHAR(2)),2,'0')||'.'||LPAD(CAST(EXTRACT(MONTH FROM r."EndsOn") AS VARCHAR(2)),2,'0')||'.'||CAST(EXTRACT(YEAR FROM r."EndsOn") AS VARCHAR(4)) AS "EndsOn",TRIM(r."PassportNo") AS "PassportNo",r."FullName",LPAD(CAST(EXTRACT(DAY FROM r."BirthDate") AS VARCHAR(2)),2,'0')||'.'||LPAD(CAST(EXTRACT(MONTH FROM r."BirthDate") AS VARCHAR(2)),2,'0')||'.'||CAST(EXTRACT(YEAR FROM r."BirthDate") AS VARCHAR(4)) AS "BirthDate",TRIM(r."Gender") AS "Gender",r."CountryName",r."PolicyCoverage",TRIM(r."CurrencyLabel") AS "CurrencyLabel",REPLACE(CAST(r."PolicyFactor" AS VARCHAR(30)),'.',',') AS "PolicyFactor",REPLACE(CAST(r."PolicyRate" AS VARCHAR(30)),'.',',') AS "PolicyRate",r."RateDate",r."Days",REPLACE(CAST(r."DailyServicesRUB" AS VARCHAR(30)),'.',',') AS "DailyServicesRUB",REPLACE(CAST(r."PremiumRUB" AS VARCHAR(30)),'.',',') AS "PremiumRUB",r."CoverageRUB",r."AgentID",r."AgentName",r."ContractNo",r."CommissionPct",CAST((SELECT LIST(u."ServiceName"||' / '||k."CategoryName"||' / '||CAST(j."AgreedPrice" AS VARCHAR(20))||' руб./день', '; ') FROM "PolicyService" j JOIN "Service" u ON u."ServiceCode"=j."ServiceCode" JOIN "ServiceCategory" k ON k."CategoryCode"=u."CategoryCode" WHERE j."PolicyID"=r."PolicyID") AS VARCHAR(2000)) AS "ServicesList" FROM "PolicySummary" r ORDER BY r."PolicyID";

-- 20_Договоры_для_слияния_Writer
SELECT d."ContractNo",d."AgentID",LPAD(CAST(EXTRACT(DAY FROM d."ContractDate") AS VARCHAR(2)),2,'0')||'.'||LPAD(CAST(EXTRACT(MONTH FROM d."ContractDate") AS VARCHAR(2)),2,'0')||'.'||CAST(EXTRACT(YEAR FROM d."ContractDate") AS VARCHAR(4)) AS "ContractDate",LPAD(CAST(EXTRACT(DAY FROM d."ContractStart") AS VARCHAR(2)),2,'0')||'.'||LPAD(CAST(EXTRACT(MONTH FROM d."ContractStart") AS VARCHAR(2)),2,'0')||'.'||CAST(EXTRACT(YEAR FROM d."ContractStart") AS VARCHAR(4)) AS "ContractStart",LPAD(CAST(EXTRACT(DAY FROM d."ContractEnd") AS VARCHAR(2)),2,'0')||'.'||LPAD(CAST(EXTRACT(MONTH FROM d."ContractEnd") AS VARCHAR(2)),2,'0')||'.'||CAST(EXTRACT(YEAR FROM d."ContractEnd") AS VARCHAR(4)) AS "ContractEnd",REPLACE(CAST(d."CommissionPct" AS VARCHAR(30)),'.',',') AS "CommissionPct",TRIM(d."BankBIK") AS "BankBIK",TRIM(d."BankAccount") AS "BankAccount",d."BankName",a."AgentName",TRIM(a."AgentPassport") AS "AgentPassport",LPAD(CAST(EXTRACT(DAY FROM a."IssueDate") AS VARCHAR(2)),2,'0')||'.'||LPAD(CAST(EXTRACT(MONTH FROM a."IssueDate") AS VARCHAR(2)),2,'0')||'.'||CAST(EXTRACT(YEAR FROM a."IssueDate") AS VARCHAR(4)) AS "IssueDate",a."Issuer" FROM "AgentContract" d JOIN "Agent" a ON a."AgentID"=d."AgentID" ORDER BY d."ContractNo";
